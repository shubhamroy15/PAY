<?php

if (!defined("WHMCS")) {
    die("This file cannot be accessed directly");
}

function bharatpe_MetaData()
{
    return array(
        'DisplayName' => 'BharatPe',
        'APIVersion' => '1.0', 
        'DisableLocalCreditCardInput' => true,
        'TokenisedStorage' => false,
    );
}

function bharatpe_config()
{
    return array(
        'FriendlyName' => array(
            'Type' => 'System',
            'Value' => 'BharatPe PG',
        ),
        'secretKey' => array(
            'FriendlyName' => 'Token',
            'Type' => 'text',
            'Size' => '250',
            'Default' => '',
            'Description' => 'Enter Token here',
        ),
        'upiid' => array(
            'FriendlyName' => 'UPI ID',
            'Type' => 'text',
            'Size' => '250',
            'Default' => '',
            'Description' => 'Enter Your UPI Id here',
        ),
        'madeby' => array(
            'FriendlyName' => 'Made By',
            'Type' => 'text',
            'Size' => '250',
            'Default' => 'LightDns',
            'Description' => 'Enter Your Company Name',
        ), 
        'folder' => array(
            'FriendlyName' => 'Custom Folder Name',
            'Type' => 'text',
            'Size' => '250',
            'Default' => 'LightDns',
            'Description' => 'Enter Your Getway File Folder Name Default `LightDns`',
        )

    );
}

function bharatpe_link($params)
{
    $upi = $params['upiid'];
    $invoiceId = $params['invoiceid'];
    $amount = $params['amount'];
    $madeby = $params['madeby'];
    $colde = $params['folder'];
    $url = $params['systemurl'] . $colde . '/BharatPe.php';
    $postfields = array();
    $postfields['upiuid'] = $upi;
    $postfields['txnAmount'] = $amount;
    $postfields['txnNote'] = $invoiceId;
    $postfields['sysurl'] = $params['systemurl'];
    $postfields['madeby'] = $madeby;


    $code = '<form method="post" action=' . $url . '>';
    foreach ($postfields as $key => $value) {
        $code .= '<input type="hidden" name="' . $key . '" value="' . $value . '"/>';
    }
    $code .= '<input type="hidden" name="checksum" value="' . $postfields . '"/><input type="submit" value="Pay with QR UPI" /></form>';
    return $code;
}
