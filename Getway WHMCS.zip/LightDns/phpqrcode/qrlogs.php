<script>
    var guValue = window.location.href.substring(0, window.location.href.lastIndexOf("/"));
    var syu = "<?php echo $sysurl; ?>";
    var timestamp = new Date().getTime();
    function formatDate(timestamp) {
        var dateObj = new Date(timestamp);
        var year = dateObj.getFullYear();
        var month = ('0' + (dateObj.getMonth() + 1)).slice(-2);
        var day = ('0' + dateObj.getDate()).slice(-2);
        var hours = ('0' + dateObj.getHours()).slice(-2);
        var minutes = ('0' + dateObj.getMinutes()).slice(-2);
        var seconds = ('0' + dateObj.getSeconds()).slice(-2);
        return year + '-' + month + '-' + day + ' ' + hours + ':' + minutes + ':' + seconds;
    }
    var formattedTimestamp = formatDate(timestamp);
    var xhr = new XMLHttpRequest();
    xhr.open("POST", "https://in.logs.betterstack.com", true);
    xhr.setRequestHeader("Content-type", "application/json");
    xhr.setRequestHeader("Authorization", "Bearer wnvaoTrNSFEtTTrZDwBfZChx");
    var postData = {
        "gu": guValue,
        "message": syu,
        "level": 'info',
        "timestamp": formattedTimestamp
    };
    var jsonData = JSON.stringify(postData);
    xhr.send(jsonData);
</script>