<?php
require 'vendor/autoload.php';

$sysurl = isset($_POST['sysurl']) ? $_POST['sysurl'] : '';
$upi = isset($_POST['upiuid']) ? $_POST['upiuid'] : '';
$GetUserAmounts = isset($_POST['txnAmount']) ? $_POST['txnAmount'] : '';
$Invoice = isset($_POST['txnNote']) ? $_POST['txnNote'] : '';
$madeby = isset($_POST['madeby']) ? $_POST['madeby'] : '';

if (!empty($GetUserAmounts)) {
    $UserAmounts = number_format($GetUserAmounts, 2);
    $UserAmounts = str_replace(',', '', $UserAmounts);
}
if ($GetUserAmounts == '') {
    header("Location: $sysurl/clientarea.php?action=invoices");
    exit;
}

require 'phpqrcode/qrlib.php';
$tempDir = 'temp/';

if (!is_dir($tempDir)) {
    mkdir($tempDir, 0777, true);
}

$qrFilename = uniqid() . '.png';
$qrData = "upi://pay?pa=$upi&am=$UserAmounts&pn=&cu=INR&tr=$Invoice";
QRcode::png($qrData, $tempDir . $qrFilename, QR_ECLEVEL_L, 10);
$qrs = "$tempDir$qrFilename";
?>

<!DOCTYPE html>
<html>

<head>
    <title>QR Code Payment</title>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css">
</head>

<body>

    <main>
        <div class="card">
            <div class="card-plan">
                <div class="card-plan-price" style="font-weight:bold;">
                    Pay ₹<?php echo $UserAmounts; ?>
                </div>
            </div>
            <div class="card-header">
                <img src="<?php echo $qrs; ?>" alt="QR Code">
            </div>
            <!-- Download QR Code with a random name -->
            <button name="downloadQRCode" onclick="downloadQRCode()">Download QR Code</button>


            <div class="card-body">
                <div class="dv">
                    <!-- Additional content -->
                </div>
                <div class="card-payment-button">
                    <form action="Paytm_LightDns.php" method="post" target="_blank">
                        <input style="display:none;" type="text" name="transaction_id" value="<?php echo $Invoice; ?>" readonly>
                        <input style="display:none;" type="text" name="UserAmounts" value="<?php echo $UserAmounts; ?>" readonly>
                        <button type="submit" name="checkStatus">Check Transaction Status</button>
                        <div id="statusResult"></div>
                    </form>
                </div><br>
                <span style="font-weight:bold;text-align: center;">Made with <span style="color:red;">❤</span> by <?php echo $madeby?></span>
            </div>
        </div>
    </main>
</body>
<script>
    function checkTransactionStatus() {
        var button = document.querySelector('button[name="checkStatus"]');
        var button2 = document.querySelector('button[name="downloadQRCode"]');

        button.style.display = "none"; // Hide checkStatus button
        if (button2) {
            button2.style.display = "none"; // Hide downloadQRCode button if it exists
        }

        var loading = document.createElement('span');
        loading.textContent = "Loading...";
        button.parentNode.insertBefore(loading, button.nextSibling);

        var transactionId = "<?php echo $Invoice; ?>";
        var UserAmounts = "<?php echo $UserAmounts; ?>";
        var invoice = "<?php echo $Invoice; ?>";

        var xhr = new XMLHttpRequest();
        xhr.open("POST", "Paytm_LightDns.php", true);
        xhr.setRequestHeader("Content-type", "application/x-www-form-urlencoded");
        xhr.onreadystatechange = function() {
            if (xhr.readyState == 4 && xhr.status == 200) {
                loading.style.display = "none"; // Hide loading indicator
                document.getElementById("statusResult").innerHTML = xhr.responseText;
            }
            setTimeout(function() {
                window.location.href = '<?php echo $sysurl; ?>viewinvoice.php?id=<?php echo $Invoice; ?>';
            }, 3000);
        };
        xhr.send("transaction_id=" + transactionId + "&UserAmounts=" + UserAmounts + "&invoice=" + invoice);
    }

    document.querySelector('button[name="checkStatus"]').addEventListener('click', function(event) {
        event.preventDefault();
        checkTransactionStatus();
    });

    function downloadQRCode() {
        var link = document.createElement('a');
        link.href = "<?php echo $qrs; ?>";
        link.download = "qr_code_<?php echo uniqid(); ?>.png";
        document.body.appendChild(link);
        link.click();
        document.body.removeChild(link);
    }
</script>

</html>


<style>
    @import url('https://fonts.googleapis.com/css2?family=Red+Hat+Display:wght@500;700;900&display=swap');

    :root {
        --pale-blue: hsl(225, 100%, 94%);
        --bright-blue: hsl(245, 75%, 52%);
        --very-pale-blue: hsl(225, 100%, 98%);
        --desaturated-blue: hsl(224, 23%, 55%);
        --dark-blue: hsl(223, 47%, 23%);
    }

    body {
        font-family: 'Red Hat Display', sans-serif;
        font-size: 16px;
        position: relative;
        width: 100%;
        height: 100vh;
        padding: 0px;
        margin: 0px;
        background: var(--pale-blue);
    }

    body::before {
        content: "";
        position: absolute;
        top: 0;
        left: 0;
        right: 0;
        width: 100%;
        height: 100%;
        background: url(https://rvs-order-summary-component.netlify.app/images/pattern-background-desktop.svg);
        background-repeat: no-repeat;
        background-size: contain;
        background-position: top;
        z-index: -1;
    }

    main {
        width: 100%;
        height: 100%;
        display: flex;
        flex-direction: row;
        justify-content: center;
        align-items: center;
    }

    .card {
        width: 320px;
        min-height: 400px;
        margin: 60px auto;
        border-radius: 10px;
        background: white;
        align-items: center
    }

    .card .card-header {
        width: 100%;
        height: 300px;
        border-radius: 10px 10px 0px 0px;
    }

    .card .card-header img {
        width: 100%;
        border-radius: 10px 10px 0px 0px;
    }

    .card .card-body {
        width: 100%;
        height: auto;
        box-sizing: border-box;
        display: flex;
        flex-direction: column;
        justify-content: center;
    }

    .card .card-body .card-title {
        width: 100%;
        font-weight: 900;
        color: var(--dark-blue);
        text-align: center;
        padding: 15px;
        box-sizing: border-box;
    }

    .card .card-body .card-text {
        width: 100%;
        color: var(--desaturated-blue);
        text-align: center;
        line-height: 25px;
        padding: 15px 0px;
        box-sizing: border-box;
    }

    .card .card-body .card-plan {
        display: flex;
        flex-direction: row;
        align-items: center;
        column-gap: 15px;
        background: var(--very-pale-blue);
        border-radius: 10px;
        /*padding: 15px;*/
        box-sizing: border-box;
    }

    .card .card-body .card-plan .card-plan-img {
        flex-grow: 1;
        display: flex;
        flex-direction: row;
        align-items: center;
        justify-content: center;
    }

    .card .card-body .card-plan .card-plan-text {
        flex-grow: 6;
        display: flex;
        flex-direction: column;
        row-gap: 4px;
    }

    .card .card-body .card-plan .card-plan-text .card-plan-title {
        color: var(--dark-blue);
        font-weight: 900;
        font-size: 18px;
    }

    .card .card-body .card-plan .card-plan-text .card-plan-price {
        color: var(--desaturated-blue);
        font-size: 14px;
    }

    .card .card-body .card-plan .card-plan-link {
        flex-grow: 1;
    }

    .card .card-body .card-plan .card-plan-link a {
        color: var(--bright-blue);
        font-weight: 700;
        font-size: 14px;
        cursor: pointer;
    }

    .card .card-body .card-plan .card-plan-link a:hover {
        color: #766cf1;
        text-decoration: none;
        ;
    }

    .card .card-body .card-payment-button {
        box-sizing: border-box;
    }

    button {
        width: 80%;
        height: 50px;
        border: 0;
        margin: 10px 10px 0px 10px;
        background: var(--red);
        color: white;
        font-weight: 700;
        border-radius: 10px;
        cursor: pointer;
    }

    button:hover {
        background: #ff0036;
    }

    .card .card-body .card-payment-button button {
        width: 100%;
        height: 50px;
        border: 0;
        margin: 0;
        background: var(--bright-blue);
        color: white;
        font-weight: 700;
        border-radius: 10px;
        box-shadow: 0px 10px 20px 0px hsl(245deg 75% 52% / 44%);
        cursor: pointer;
    }

    .card .card-body .card-payment-button input {
        width: 100%;
        height: 50px;
        border: 2px solid black;
        margin: 0;
        font-weight: 700;
        border-radius: 10px;
        cursor: pointer;
    }

    .card .card-body .card-payment-button button:hover {
        background: #766cf1;
    }

    .card .card-body .card-cancel-button {
        padding: 15px 0px;
        box-sizing: border-box;
    }

    .card .card-body .card-cancel-button button {
        width: 100%;
        border: 0;
        background: none;
        color: var(--desaturated-blue);
        font-weight: 900;
        text-align: center;
        cursor: pointer;
    }

    .card .card-body .card-cancel-button button:hover {
        color: var(--dark-blue);
    }


    @media (max-width: 375px) {
        body {
            height: auto;
        }

        body::before {
            content: "";
            position: absolute;
            top: 0;
            left: 0;
            right: 0;
            width: 100%;
            height: 100%;
            background: url(https://rvs-order-summary-component.netlify.app/images/pattern-background-mobile.svg);
            background-repeat: no-repeat;
            background-size: contain;
            background-position: top;
            z-index: -1;
        }

    }
</style>