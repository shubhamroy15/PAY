<?php
include("../init.php");
include("../includes/functions.php");
include("../includes/gatewayfunctions.php");
include("../includes/invoicefunctions.php");

$gatewaymodule = "PayTm";

$GATEWAY = getGatewayVariables($gatewaymodule);

$transaction_id = isset($_POST['transaction_id']) ? $_POST['transaction_id'] : '';
$UserAmounts = isset($_POST['UserAmounts']) ? $_POST['UserAmounts'] : '';
$UserAmounts = preg_replace('/[^0-9.]/', '', $UserAmounts);
$Invoice = isset($_POST['invoice']) ? $_POST['invoice'] : '';
$token = $GATEWAY['secretKey'];
$gatewaymodule = $GATEWAY['FriendlyName'];

if ($_SERVER['REQUEST_METHOD'] === 'POST' && !empty($transaction_id)) {
    $url = "https://securegw.paytm.in/merchant-status/getTxnStatus?JsonData=";

    $data = array(
        'MID' => $token,
        'ORDERID' => $transaction_id,
    );

    $json_data = json_encode($data);
    $url .= $json_data;
    $checksum = hash_hmac('sha256', $json_data, $merchant_key);
    $url .= "&CHECKSUMHASH=" . $checksum;

    $response = file_get_contents($url);
    $response_data = json_decode($response, true);

    if ($response_data['STATUS'] == 'TXN_SUCCESS' && $response_data['ORDERID'] == $transaction_id && $response_data['MID'] == $token && $response_data['TXNAMOUNT']) {
        $status = 'success';
        $amount = $response_data['TXNAMOUNT'];
        $payMode = $response_data['PAYMENTMODE'];
        $utr =  $response_data['BANKTXNID'];
        $txnId =  $response_data['TXNID'];

        if (empty($utr)) {
            $utr = $txnId;
        }

        if ($amount == $UserAmounts) {
            if (!isTransactionIdExists($utr)) {
                addInvoicePayment($Invoice, $utr, $amount, $amount, $gatewaymodule);
                update_query("tblinvoices", array("notes" => "Paid By $payMode and UTR Id  $utr"), array("id" => $Invoice));
                logTransaction($GATEWAY["name"], $response, "Successful");
                echo "<p style='font-weight:bold;background-color: #dff0d8;padding: 10px;border-radius: 10px;'>Status: <span style='color:#3c763d;'>Invoice Updated</span></p>";
            } else {
                echo "<p style='font-weight:bold;background-color: #f2dede;padding: 10px;border-radius: 10px;color: black;'>Status: <span style='color: red;'>Invoice Update Failed Contact Support Team</span></p>";
            }
        } else {
            echo "<p style='font-weight:bold;background-color: #f2dede;padding: 10px;border-radius: 10px;'>&#128546; Transaction failed, you paid only ₹<span>$amount</span> &#129402; you need to pay total ₹<span>$UserAmounts</span> &#128526;</p>";
        }
    } else {
        $status = 'failed';
        echo "<p style='font-weight:bold;background-color: #f2dede;padding: 10px;border-radius: 10px;'>Status: <span style='color:#a94442;'>Transaction Failed</span></p>";
    }
}
function isTransactionIdExists($transaction_id)
{
    $result = select_query("tblaccounts", "id", array("transid" => $transaction_id));
    return mysql_num_rows($result) > 0;
}
