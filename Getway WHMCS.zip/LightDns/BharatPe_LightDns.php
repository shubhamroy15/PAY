<?php
include("../init.php");
include("../includes/functions.php");
include("../includes/gatewayfunctions.php");
include("../includes/invoicefunctions.php");

$gatewaymodule = "BharatPe";

$GATEWAY = getGatewayVariables($gatewaymodule);

$transaction_id = isset($_POST['transaction_id']) ? $_POST['transaction_id'] : '';
$UserAmounts = isset($_POST['UserAmounts']) ? $_POST['UserAmounts'] : '';
$UserAmounts = preg_replace('/[^0-9.]/', '', $UserAmounts);
$Invoice = isset($_POST['invoice']) ? $_POST['invoice'] : '';
$token = $GATEWAY['secretKey'];
$gatewaymodule = $GATEWAY['FriendlyName'];

if ($_SERVER['REQUEST_METHOD'] === 'POST' && !empty($transaction_id)) {
    $url = "https://api.lightdns.org/api.php?token=$token&txn_id=$transaction_id";
    $response = file_get_contents($url);
    $response_data = json_decode($response, true);
    if ($response_data['status'] == 'SUCCESS') {
        $status = 'success';
        $amount = $response_data['amount'];
        $payMode = $response_data['app'];
        $payer = $response_data['payer'];
        if ($amount == $UserAmounts) {
            if (!isTransactionIdExists($transaction_id)) {
                addInvoicePayment($Invoice, $transaction_id, $amount, $amount, $gatewaymodule);
                update_query("tblinvoices", array("notes" => "Paid By $payer Using $payMode and UTR Id  $transaction_id"), array("id" => $Invoice));
                logTransaction($GATEWAY["name"], $response, "Successful");
                echo "<p style='font-weight:bold;background-color: #dff0d8;padding: 10px;border-radius: 10px;'>Status: <span style='color:#3c763d;'>Invoice Updated</span></p>";
            } else {
                echo "<p style='font-weight:bold;background-color: #f2dede;padding: 10px;border-radius: 10px;color: black;'>Status: <span style='color: red;'>Invoice Update Failed Contact Support Team</span></p>";
            }
        } else {
            echo "<p style='font-weight:bold;background-color: #f2dede;padding: 10px;border-radius: 10px;'>&#128546; Transaction failed, you paid only ₹<span>$amount</span> &#129402; you need to pay total ₹<span>$UserAmounts</span> &#128526;</p>";
        }
    } else {
        $status = 'failed';
        echo "<p style='font-weight:bold;background-color: #f2dede;padding: 10px;border-radius: 10px;'>Status: <span style='color:#a94442;'>Transaction Failed</span></p>";
    }
}
function isTransactionIdExists($transaction_id)
{
    $result = select_query("tblaccounts", "id", array("transid" => $transaction_id));
    return mysql_num_rows($result) > 0;
}
